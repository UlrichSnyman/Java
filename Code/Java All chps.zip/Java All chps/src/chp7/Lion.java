package chp7;

public class Lion extends Animal {
}
