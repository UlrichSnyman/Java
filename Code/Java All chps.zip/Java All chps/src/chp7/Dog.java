package chp7;

public class Dog extends Animal {
}
