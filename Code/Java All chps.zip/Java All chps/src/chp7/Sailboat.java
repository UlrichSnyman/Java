package chp7;

public class Sailboat extends Boat {
  public void move() {
    System.out.print("hoist sail ");
  }
}
