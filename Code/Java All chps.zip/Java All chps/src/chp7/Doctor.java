package chp7;

public class Doctor {

  boolean worksAtHospital;

  void treatPatient() {
    // perform a checkup

  }
}

