package chp7;

public class Cat extends Animal {
}
