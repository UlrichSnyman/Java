package chp7;

public class Animal {
  public void eat() {
    System.out.println("nom nom nom");
  }

  public void roam() {
    System.out.println("walking around");
  }

  public void makeNoise() {
    System.out.println("making some noise");
  }
}
