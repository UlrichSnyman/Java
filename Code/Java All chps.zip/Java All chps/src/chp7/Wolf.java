package chp7;

public class Wolf extends Animal {
  public void makeNoise() {

  }

  public void roam() {

  }

  public void eat() {

  }

  public void sleep() {

  }
}
