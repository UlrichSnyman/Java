package chp7;

public class Hippo extends Animal {
}
