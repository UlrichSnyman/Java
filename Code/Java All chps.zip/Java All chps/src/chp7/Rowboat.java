package chp7;

public class Rowboat extends Boat {
  public void rowTheBoat() {
    System.out.print("stroke natasha");
  }
}
