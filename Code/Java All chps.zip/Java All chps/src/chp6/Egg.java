package chp6;

public class Egg {
}
