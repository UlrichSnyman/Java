package chp5;

public class Snippets {
  void forLoop() {
    for (int i = 0; i < 8; i++) {
      System.out.println(i);
    }
    System.out.println("done");
  }

  void whileLoop() {
    int i = 0;
    while (i < 8) {
      System.out.println(i);
      i++;
    }
    System.out.println("done");
  }

}
