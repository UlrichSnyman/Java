package chp9;

public class StackExample {
  public void doStuff() {
    boolean b = true;
    go(4);
  }

  public void go(int x) {
    int z = x + 24;
    crazy();
    // imagine more code here
  }

  public void crazy() {
    char c = 'a';
  }
}
