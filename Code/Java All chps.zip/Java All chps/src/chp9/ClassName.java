package chp9;

public class ClassName {
  public ClassName() {
    super();
  }
}
