package chp9;

public class Animal {
   public Animal() {
      System.out.println("Making an Animal");
   }
}


