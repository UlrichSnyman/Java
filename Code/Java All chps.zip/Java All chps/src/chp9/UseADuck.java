package chp9;

public class UseADuck {

  public static void main (String[] args) {
    Duck d = new Duck(42);
  }
}