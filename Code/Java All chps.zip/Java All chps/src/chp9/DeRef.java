package chp9;

public class DeRef {
  Duck d = new Duck();

  public void go() {
    d = null;
  }
}
