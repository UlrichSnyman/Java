package chp9;

public class Mushroom {
  public Mushroom(int size) {
  }

  public Mushroom() {
  }

  public Mushroom(boolean isMagic) {
  }

  public Mushroom(boolean isMagic, int size) {
  }

  public Mushroom(int size, boolean isMagic) {
  }
}