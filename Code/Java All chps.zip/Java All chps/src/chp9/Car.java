package chp9;

public class Car {
  private String size;

  public Car(String size) {
    this.size = size;
  }
}
