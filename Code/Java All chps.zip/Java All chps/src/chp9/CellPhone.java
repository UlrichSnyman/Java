package chp9;

public class CellPhone {
  private Antenna ant;

  private class Antenna {
  }
}