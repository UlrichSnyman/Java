package chp9;

public class Hippo extends Animal {
  public Hippo() {
    System.out.println("Making a Hippo");
  }
}
