package chp9;

public class Snippets {
  public void foo(int x) {
    int i = x + 3;
    boolean b = true;
  }
}
