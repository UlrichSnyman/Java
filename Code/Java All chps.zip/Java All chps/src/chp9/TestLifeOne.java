package chp9;

public class TestLifeOne {
  public void read() {
    int s = 42;
    sleep();
  }


  public void sleep() {
//    s = 7;
  }
}