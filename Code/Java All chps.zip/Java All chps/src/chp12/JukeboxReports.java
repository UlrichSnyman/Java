package chp12;

public class JukeboxReports {
  public static void main(String[] args) {

  }

  static void printAllGenres() {

  }
}
