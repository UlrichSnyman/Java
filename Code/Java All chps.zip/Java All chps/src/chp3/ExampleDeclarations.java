package chp3;

public class ExampleDeclarations {
  void declarations() {
    int x;
    x = 234;
    byte b = 89;
    boolean isFun = true;
    double d = 3456.98;
    char c = 'f';
    int z = x;
    boolean isPunkRock;
    isPunkRock = false;
    boolean powerOn;
    powerOn = isFun;
    long big = 3456789L;
    float f = 32.5f;
  }

  void declareLiterals() {
    int x = 234;


    int size = 32;
    char initial = 'j';
    double d = 456.709;
    boolean isLearning;
    isLearning = true;
    int y = x + 456;

  }

  void invalidNames() {
//    int _;
//    int abstract;
//    int assert;
//    int boolean;
//    int break;
//    int byte;
//    int case;
//    int catch;
//    int char;
//    int class;
//    int const;
//    int continue;
//    int default;
//    int do;
//    int   double;
//    int else;
//    int enum;
    int exports;
//    int extends;
//    int final;
//    int finally;
//    int float;
//    int for;
//    int goto;
//    int if;
//    int implements;
//    int import;
//    int instanceof;
//    int int;
//    int interface;
//    int long;
    int module;
//    int native;
//    int new;
//    int         non-sealed;
//    int null;
    int open;
    int opens;
//    int package;
    int permits;
//    int private;
//    int protected;
    int provides;
//    int public;
    int record;
    int requires;
//    int return;
    int sealed;
//    int short;
//    int static;
//    int strictfp;
//    int super;
//    int switch;
//    int synchronized;
//    int this;
//    int throw;
//    int throws;
    int to;
//    int transient;
    int transitive;
//    int try;
    int uses;
    int var;
//    int void;
//    int volatile;
//    int while;
    int with;
    int yield;
//    int false;
//    int true;

  }


}
