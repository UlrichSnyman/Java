package chp3;

public class Sharpen {
  void sharpen() {
//    int x = 34.5;
//    boolean boo = x;
    int g = 17;
    int y = g;
    y = y + 10;
    short s;
//    s = y;
    byte b = 3;
    byte v = b;
    short n = 12;
//    v = n;
//    byte k = 128;
  }
}
