package chp2;

class DogTestDrive {
  public static void main(String[] args) {
    Dog d = new Dog();
    d.size = 40;
    d.bark();
      System.out.println( d.size);
  }
}