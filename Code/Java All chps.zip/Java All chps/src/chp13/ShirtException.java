package chp13;

public class ShirtException extends ClothingException {
    public ShirtException(String message) {
        super(message);
    }
}
