package chp13.sharpen;

public class BetaEx extends GammaEx {
}
