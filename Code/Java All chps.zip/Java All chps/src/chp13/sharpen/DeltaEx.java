package chp13.sharpen;

public class DeltaEx extends Exception {
}
