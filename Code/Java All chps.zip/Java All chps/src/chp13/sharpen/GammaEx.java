package chp13.sharpen;

public class GammaEx extends DeltaEx {
}
