package chp13.sharpen;

public class AlphaEx extends BetaEx {
}
