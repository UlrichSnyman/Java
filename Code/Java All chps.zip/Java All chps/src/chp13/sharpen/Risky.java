package chp13.sharpen;

public class Risky {
  public void doRisky() throws DeltaEx {
    throw new DeltaEx();
  }
}
