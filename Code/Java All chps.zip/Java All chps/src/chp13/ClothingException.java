package chp13;

// Base Exception
class ClothingException extends Exception {
    public ClothingException(String message) {
        super(message);
    }
}