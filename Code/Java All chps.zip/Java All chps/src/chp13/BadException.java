package chp13;

public class BadException extends Exception {
}
