package chp13;

class LingerieException extends ClothingException {
    public LingerieException(String message) {
        super(message);
    }
}