package chp13;

public class PantsException extends ClothingException {
    public PantsException(String message) {
        super(message);
    }
}
