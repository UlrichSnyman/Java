package chp13;

// Subclasses of ClothingException
class TeeShirtException extends ClothingException {
    public TeeShirtException(String message) {
        super(message);
    }
}