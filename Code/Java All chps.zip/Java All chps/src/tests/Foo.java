package tests;

public class Foo {
    static int x;
    public void go() {
        System.out.println(x);
    }
}