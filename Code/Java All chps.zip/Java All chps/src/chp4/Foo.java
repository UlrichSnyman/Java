package chp4;

class Foo {
  public void go() {
    // intentionally doesn't compile
//    int x;
//    int z = x + 3;
  }
}