package chp4;

class Horse {
  private double height = 15.2;
  private String breed;
  // more code...
}