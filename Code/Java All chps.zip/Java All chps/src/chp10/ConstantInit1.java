package chp10;

class ConstantInit1 {
  final static int X;

  static {
    X = 42;
  }
}