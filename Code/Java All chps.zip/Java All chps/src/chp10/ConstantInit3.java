package chp10;

public class ConstantInit3 {
  public static final double VAL;

  static {
    VAL = Math.random();
  }
}