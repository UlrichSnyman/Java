package chp10;

class Poof {
  final void calcWhuffie() {
    // important things
    // that must never be overridden
  }
}