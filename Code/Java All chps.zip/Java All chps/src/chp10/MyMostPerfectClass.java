package chp10;

final class MyMostPerfectClass {
  // cannot be extended
}