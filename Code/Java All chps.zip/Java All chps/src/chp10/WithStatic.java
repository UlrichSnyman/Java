package chp10;

import static java.lang.Math.*;
import static java.lang.System.out;

class WithStatic {
  public static void main(String[] args) {
    out.println("sqrt " + sqrt(2.0));
    out.println("tan " + tan(60));
  }
}