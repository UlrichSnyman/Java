package chp10;

class NoStatic {
  public static void main(String[] args) {
    System.out.println("sqrt " + Math.sqrt(2.0));
    System.out.println("tan " + Math.tan(60));
  }
}