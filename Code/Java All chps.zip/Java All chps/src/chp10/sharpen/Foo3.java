package chp10.sharpen;

public class Foo3 {
//  final int x;

  public void go() {
//    System.out.println(x);
  }
}