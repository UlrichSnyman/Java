package chp10.sharpen;

public class Foo4 {
  static final int x = 12;

  public void go() {
    System.out.println(x);
  }
}