package chp10.sharpen;

public class Foo2 {
  int x;

  public static void go() {
//    System.out.println(x);
  }
}