package chp10.sharpen;

public class Foo6 {
  int x = 12;

  public static void go(final int x) {
    System.out.println(x);
  }
}