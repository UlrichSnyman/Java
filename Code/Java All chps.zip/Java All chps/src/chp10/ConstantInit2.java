package chp10;

public class ConstantInit2 {
   public static final int X_VALUE = 25;
}
