package chp8;

public class Dog extends Canine implements Pet {
  public void beFriendly() {

  }

  public void play() {

  }

  public void roam() {

  }

  public void eat() {

  }
}