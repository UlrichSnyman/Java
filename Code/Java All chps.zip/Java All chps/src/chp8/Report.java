package chp8;

abstract class Report {
  void runReport() {
    // set-up report
  }

  void printReport() {
    // generic printing
  }
}

