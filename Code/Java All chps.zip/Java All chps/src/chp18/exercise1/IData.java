package chp18.exercise1;

import java.util.List;

public interface IData {
  void addLetter(char c);

  List<String> getLetters();
}
