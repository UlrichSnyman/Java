package chp1; // Same as folder name

public class MyFirstApp {
    public static void main(String[] args)
    // Public means accessible from anywhere
    // Static means that the method is not tied to an object
    // void means that the method does not return anything
    // Main is the name of the method
    // String[] args is the name of the parameter
    {
        System.out.println("Hello World!");
        System.out.printf("Hello World!");
    }

}
