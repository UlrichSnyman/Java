package chp16;

public class Duck {
  // duck code here
}