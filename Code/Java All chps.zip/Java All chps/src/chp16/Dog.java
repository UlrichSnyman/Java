package chp16;

public class Dog {

  static final long serialVersionUID =
          -6849794470754667710L;

  private String name;
  private int size;

  // method code here
}